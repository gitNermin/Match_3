﻿using UnityEngine;

    [CreateAssetMenu(fileName = "new Gems Collection", menuName = "Game/GemsCollection", order = 0)]
    public class GemsCollection : Collection<Gem>
    {
        
    }